

#import "ViewController.h"
#import "FlipView.h"
#import "KxMenu.h"
NS_ENUM(NSUInteger,GTNNumberType){
    GTNNumberType4x3 = 0,
    GTNNumberType4x4 ,
    GTNNumberType5x5 ,
    GTNNumberType6x6 ,
};

@interface ViewController ()<FlipViewDelegate>
@property (assign,nonatomic) enum GTNNumberType type;


@property (weak, nonatomic) IBOutlet UIButton *startBtn;
@property (weak, nonatomic) IBOutlet UIButton *resetBtn;
@property (assign,nonatomic) NSInteger indexID;


@property (weak, nonatomic) IBOutlet UILabel *stepLabel;
@property (weak, nonatomic) IBOutlet UILabel *targetLabel;


#pragma mark - 4x3
@property (weak, nonatomic) IBOutlet UIView *marix4x3;

@property (strong,nonatomic) NSMutableArray *numbersArray;

@property (weak, nonatomic) IBOutlet FlipView *guessbtn00;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn01;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn02;

@property (weak, nonatomic) IBOutlet FlipView *guessbtn10;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn11;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn12;



@property (weak, nonatomic) IBOutlet FlipView *guessbtn20;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn22;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn21;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn30;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn31;
@property (weak, nonatomic) IBOutlet FlipView *guessbtn32;


#pragma mark - 4x4
@property (weak, nonatomic) IBOutlet UIView *marix4x4;

@property (strong,nonatomic) NSMutableArray *number4x4Array;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnA00;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA01;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA02;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA03;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnA10;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA11;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA12;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA13;


@property (weak, nonatomic) IBOutlet FlipView *guessbtnA20;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA22;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA21;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA23;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnA30;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA31;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA32;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnA33;

#pragma mark - 5x5

@property (weak, nonatomic) IBOutlet UIView *marix5x5;

@property (strong,nonatomic) NSMutableArray *numbers5x5Array;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnB00;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB01;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB02;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB03;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB04;


@property (weak, nonatomic) IBOutlet FlipView *guessbtnB10;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB11;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB12;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB13;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB14;



@property (weak, nonatomic) IBOutlet FlipView *guessbtnB20;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB22;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB21;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB23;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB24;


@property (weak, nonatomic) IBOutlet FlipView *guessbtnB30;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB31;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB32;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB33;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB34;


@property (weak, nonatomic) IBOutlet FlipView *guessbtnB40;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB41;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB42;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB43;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnB44;

#pragma mark - 6x6
@property (weak, nonatomic) IBOutlet UIView *marix6x6;

@property (strong,nonatomic) NSMutableArray *numbers6x6Array;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnC00;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC01;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC02;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC03;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC04;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC05;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnC10;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC11;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC12;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC13;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC14;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC15;


@property (weak, nonatomic) IBOutlet FlipView *guessbtnC20;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC22;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC21;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC23;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC24;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC25;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnC30;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC31;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC32;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC33;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC34;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC35;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnC40;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC41;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC42;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC43;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC44;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC45;

@property (weak, nonatomic) IBOutlet FlipView *guessbtnC50;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC51;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC52;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC53;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC54;
@property (weak, nonatomic) IBOutlet FlipView *guessbtnC55;


- (IBAction)startGuess:(UIButton *)sender;
- (IBAction)resetGuess:(UIButton *)sender;
- (IBAction)settingButton:(UIButton *)sender;
- (IBAction)lookupAwer:(UIButton *)sender;



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.marix4x3.layer.cornerRadius = 4;
    self.marix4x3.layer.masksToBounds = YES;
    
    self.marix4x4.layer.cornerRadius = 4;
    self.marix4x4.layer.masksToBounds = YES;
    
    self.marix5x5.layer.cornerRadius = 4;
    self.marix5x5.layer.masksToBounds = YES;
    
    self.marix6x6.layer.cornerRadius = 4;
    self.marix6x6.layer.masksToBounds = YES;
    ////    self.flipButtonView = [[FlipButtonView alloc]init];
    ////    self.flipButtonView.backgroundColor  = [UIColor redColor];
    ////
    ////    self.flipButtonView.frame =CGRectMake(100, 100, 100, 100);
    ////    self.flipButtonView.frontImage = [UIImage imageNamed:@"02.png"];
    ////    self.flipButtonView.backImage = [UIImage imageNamed:@"02动态.png"];
    ////    [self.flipButtonView setUI];
    //
    //    [self.view addSubview:self.flipButtonView];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handerNotification) name:@"hitBtn" object:nil];
    
    
    [self setDefaltUI];
}
- (void)setDefaltUI{
    self.type = GTNNumberType4x3;
    self.targetLabel.text = @"Guess Number";
    self.numbersArray  = [NSMutableArray array];
    self.guessbtn00.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn00.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn00.number = @"0";
    [self.guessbtn00 setUI];
    self.guessbtn00.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn00];
    //
    
    self.guessbtn01.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn01.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn01.number = @"1";
    [self.guessbtn01 setUI];
    self.guessbtn01.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn01];
    
    self.guessbtn02.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn02.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn02.number = @"2";
    [self.guessbtn02 setUI];
    self.guessbtn02.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn02];
    
    
    self.guessbtn10.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn10.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn10.number = @"0";
    [self.guessbtn10 setUI];
    self.guessbtn10.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn10];
    
    
    self.guessbtn20.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn20.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn20.number = @"0";
    [self.guessbtn20 setUI];
    self.guessbtn20.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn20];
    
    self.guessbtn30.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn30.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn30.number = @"0";
    [self.guessbtn30 setUI];
    self.guessbtn30.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn30];
    
    
    self.guessbtn11.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn11.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn11.number = @"0";
    [self.guessbtn11 setUI];
    self.guessbtn11.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn11];
    
    self.guessbtn22.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn22.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn22.number = @"0";
    [self.guessbtn22 setUI];
    self.guessbtn22.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn22];
    
    self.guessbtn21.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn21.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn21.number = @"0";
    [self.guessbtn21 setUI];
    self.guessbtn21.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn21];
    
    self.guessbtn12.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn12.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn12.number = @"0";
    [self.guessbtn12 setUI];
    self.guessbtn12.mkDelegate = self;
    [self.numbersArray addObject:self.guessbtn12];
    
    
    self.guessbtn31.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn31.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn31.number = @"0";
    [self.guessbtn31 setUI];
    [self.numbersArray addObject:self.guessbtn31];
    
    self.guessbtn32.frontImage = [UIImage imageNamed:@"front"];
    self.guessbtn32.backImage = [UIImage imageNamed:@"back"];
    self.guessbtn32.number = @"0";
    [self.guessbtn32 setUI];
    [self.numbersArray addObject:self.guessbtn32];
    
    
    
    
    
}
- (void)set4x4UI{
    self.type = GTNNumberType4x4;
    self.targetLabel.text = @"Guess Number";
    self.number4x4Array  = [NSMutableArray array];
    
    [self.number4x4Array addObject:self.guessbtnA00];
    [self.number4x4Array addObject:self.guessbtnA01];
    [self.number4x4Array addObject:self.guessbtnA02];
    [self.number4x4Array addObject:self.guessbtnA03];
    
    [self.number4x4Array addObject:self.guessbtnA10];
    [self.number4x4Array addObject:self.guessbtnA11];
    [self.number4x4Array addObject:self.guessbtnA12];
    [self.number4x4Array addObject:self.guessbtnA13];
    
    [self.number4x4Array addObject:self.guessbtnA20];
    [self.number4x4Array addObject:self.guessbtnA21];
    [self.number4x4Array addObject:self.guessbtnA22];
    [self.number4x4Array addObject:self.guessbtnA23];
    
    [self.number4x4Array addObject:self.guessbtnA30];
    [self.number4x4Array addObject:self.guessbtnA31];
    [self.number4x4Array addObject:self.guessbtnA32];
    [self.number4x4Array addObject:self.guessbtnA33];
   
    for (FlipView *temp in self.number4x4Array) {
        temp.frontImage = [UIImage imageNamed:@"front"];
        temp.backImage = [UIImage imageNamed:@"back"];
        temp.number = @"0";
        [temp setUI];
        temp.mkDelegate = self;
    }
    
}
- (void)set5x5UI{
    self.type = GTNNumberType5x5;
    self.targetLabel.text = @"Guess Number";
    self.numbers5x5Array  = [NSMutableArray array];
    [self.numbers5x5Array addObject:self.guessbtnB00];
    [self.numbers5x5Array addObject:self.guessbtnB01];
    [self.numbers5x5Array addObject:self.guessbtnB02];
    [self.numbers5x5Array addObject:self.guessbtnB03];
    [self.numbers5x5Array addObject:self.guessbtnB04];
    
    
    [self.numbers5x5Array addObject:self.guessbtnB10];
    [self.numbers5x5Array addObject:self.guessbtnB11];
    [self.numbers5x5Array addObject:self.guessbtnB12];
    [self.numbers5x5Array addObject:self.guessbtnB13];
    [self.numbers5x5Array addObject:self.guessbtnB14];
    
    
    [self.numbers5x5Array addObject:self.guessbtnB20];
    [self.numbers5x5Array addObject:self.guessbtnB21];
    [self.numbers5x5Array addObject:self.guessbtnB22];
    [self.numbers5x5Array addObject:self.guessbtnB23];
    [self.numbers5x5Array addObject:self.guessbtnB24];
    
    
    [self.numbers5x5Array addObject:self.guessbtnB30];
    [self.numbers5x5Array addObject:self.guessbtnB31];
    [self.numbers5x5Array addObject:self.guessbtnB32];
    [self.numbers5x5Array addObject:self.guessbtnB33];
    [self.numbers5x5Array addObject:self.guessbtnB34];
    
    
    [self.numbers5x5Array addObject:self.guessbtnB40];
    [self.numbers5x5Array addObject:self.guessbtnB41];
    [self.numbers5x5Array addObject:self.guessbtnB42];
    [self.numbers5x5Array addObject:self.guessbtnB43];
    [self.numbers5x5Array addObject:self.guessbtnB44];
    
    for (FlipView *temp in self.numbers5x5Array) {
        temp.frontImage = [UIImage imageNamed:@"front"];
        temp.backImage = [UIImage imageNamed:@"back"];
        temp.number = @"0";
        [temp setUI];
        temp.mkDelegate = self;
    }

}
- (void)set6x6UI{
    self.type = GTNNumberType6x6;
    self.targetLabel.text = @"Guess Number";
    self.numbers6x6Array  = [NSMutableArray array];
    
    [self.numbers6x6Array addObject:self.guessbtnC00];
    [self.numbers6x6Array addObject:self.guessbtnC01];
    [self.numbers6x6Array addObject:self.guessbtnC02];
    [self.numbers6x6Array addObject:self.guessbtnC03];
    [self.numbers6x6Array addObject:self.guessbtnC04];
    [self.numbers6x6Array addObject:self.guessbtnC05];
    
    [self.numbers6x6Array addObject:self.guessbtnC10];
    [self.numbers6x6Array addObject:self.guessbtnC11];
    [self.numbers6x6Array addObject:self.guessbtnC12];
    [self.numbers6x6Array addObject:self.guessbtnC13];
    [self.numbers6x6Array addObject:self.guessbtnC14];
    [self.numbers6x6Array addObject:self.guessbtnC15];
    
    
    [self.numbers6x6Array addObject:self.guessbtnC20];
    [self.numbers6x6Array addObject:self.guessbtnC21];
    [self.numbers6x6Array addObject:self.guessbtnC22];
    [self.numbers6x6Array addObject:self.guessbtnC23];
    [self.numbers6x6Array addObject:self.guessbtnC24];
    [self.numbers6x6Array addObject:self.guessbtnC25];
    
    
    [self.numbers6x6Array addObject:self.guessbtnC30];
    [self.numbers6x6Array addObject:self.guessbtnC31];
    [self.numbers6x6Array addObject:self.guessbtnC32];
    [self.numbers6x6Array addObject:self.guessbtnC33];
    [self.numbers6x6Array addObject:self.guessbtnC34];
    [self.numbers6x6Array addObject:self.guessbtnC35];
    
    
    [self.numbers6x6Array addObject:self.guessbtnC40];
    [self.numbers6x6Array addObject:self.guessbtnC41];
    [self.numbers6x6Array addObject:self.guessbtnC42];
    [self.numbers6x6Array addObject:self.guessbtnC43];
    [self.numbers6x6Array addObject:self.guessbtnC44];
    [self.numbers6x6Array addObject:self.guessbtnC45];
    
    
    [self.numbers6x6Array addObject:self.guessbtnC50];
    [self.numbers6x6Array addObject:self.guessbtnC51];
    [self.numbers6x6Array addObject:self.guessbtnC52];
    [self.numbers6x6Array addObject:self.guessbtnC53];
    [self.numbers6x6Array addObject:self.guessbtnC54];
    [self.numbers6x6Array addObject:self.guessbtnC55];
    
    for (FlipView *temp in self.numbers6x6Array) {
        temp.frontImage = [UIImage imageNamed:@"front"];
        temp.backImage = [UIImage imageNamed:@"back"];
        temp.number = @"0";
        [temp setUI];
        temp.mkDelegate = self;
    }
    
}
- (IBAction)lookupAwer:(UIButton *)sender {
    
    
    if ([self.targetLabel.text isEqualToString:@"Guess Number"]) {
        UIAlertController *vc = [UIAlertController alertControllerWithTitle:@"you don`t start " message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok  = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [vc addAction:ok];
        [self presentViewController:vc animated:YES completion:^{
            
        }];
        return;
    }else{
        
        UIAlertController *vc = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:@"%@%@",@"The awser is ",@(self.targetLabel.tag)] message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok  = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [vc addAction:ok];
        [self presentViewController:vc animated:YES completion:^{
            
        }];
    }
}

- (IBAction)settingButton:(UIButton *)sender {
    NSArray *menuItems =
    @[
      
      [KxMenuItem menuItem:@"Set level"
                     image:nil
                    target:nil
                    action:NULL],
            
      [KxMenuItem menuItem:@"martix 4x3"
                     image:[UIImage imageNamed:@"reload"]
                    target:self
                    action:@selector(greetingHanderText:)],
      
      [KxMenuItem menuItem:@"martix 4x4"
                     image:nil
                    target:self
                    action:@selector(greetingHanderText:)],
      
      [KxMenuItem menuItem:@"martix 5x5"
                     image:[UIImage imageNamed:@"reload"]
                    target:self
                    action:@selector(greetingHanderText:)],
      [KxMenuItem menuItem:@"martix 6x6"
                     image:[UIImage imageNamed:@"reload"]
                    target:self
                    action:@selector(greetingHanderText:)],
      ];
    
    KxMenuItem *first = menuItems[0];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}
- (void)greetingHanderText:(KxMenuItem*)first{
    if ([first.title isEqualToString:@"martix 4x3"]) {
        self.marix4x3.hidden = NO;
        self.marix4x4.hidden = YES;
        self.marix5x5.hidden = YES;
        self.marix6x6.hidden = YES;
    }
    if ([first.title isEqualToString:@"martix 4x4"]) {
        self.marix4x3.hidden = YES;
        self.marix4x4.hidden = NO;
        self.marix5x5.hidden = YES;
        self.marix6x6.hidden = YES;
        
        [self set4x4UI];
    }
    if ([first.title isEqualToString:@"martix 5x5"]) {
        self.marix4x3.hidden = YES;
        self.marix4x4.hidden = YES;
        self.marix5x5.hidden = NO;
        self.marix6x6.hidden = YES;
        [self set5x5UI];
    }
    if ([first.title isEqualToString:@"martix 6x6"]) {
        self.marix4x3.hidden = YES;
        self.marix4x4.hidden = YES;
        self.marix5x5.hidden = YES;
        self.marix6x6.hidden = NO;
        [self set6x6UI];
    }
    
}
- (IBAction)startGuess:(UIButton *)sender {
    switch (self.type) {
        case GTNNumberType4x3:
            [self startDefault];
            break;
        case GTNNumberType4x4:
            [self start4x4];
            break;
        case GTNNumberType5x5:
            [self start5x5];
            break;
        case GTNNumberType6x6:
            [self start6x6];
            break;
    }
    
    
    
    
}
- (void)startDefault{
    int  k  =  arc4random() % (self.numbersArray.count - 1);
    
    int o =  arc4random() % (self.numbersArray.count - 1);
    
    self.targetLabel.text = [NSString stringWithFormat:@"%@",@(k)];
    [[NSUserDefaults standardUserDefaults] setValue:self.targetLabel.text forKey:@"target"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    for (NSInteger i = 0; i < self.numbersArray.count; i++) {
        
        
        FlipView *tempView = self.numbersArray[i];
        tempView.isUse = YES;
        if (o == i) {
            self.targetLabel.tag = i;
            tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(k)];
            tempView.number = [NSString stringWithFormat:@"%@",@(k)];
        }else{
            int m = 0;
            do{
                m  =  arc4random() % (self.numbersArray.count - 1);
                tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(m)];
                tempView.number = [NSString stringWithFormat:@"%@",@(m)];;
                //             NSLog(@"k=%@,m=%@,number=%@",@(k),@(m),tempView.numberLabel.text);
            }while( m == k);
        }
    }
}
- (void)start4x4{
    int  k  =  arc4random() % (self.number4x4Array.count - 1);
    
    int o =  arc4random() % (self.number4x4Array.count - 1);
    
    self.targetLabel.text = [NSString stringWithFormat:@"%@",@(k)];
    [[NSUserDefaults standardUserDefaults] setValue:self.targetLabel.text forKey:@"target"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    for (NSInteger i = 0; i < self.number4x4Array.count; i++) {
        
        
        FlipView *tempView = self.number4x4Array[i];
        tempView.isUse = YES;
        if (o == i) {
            self.targetLabel.tag = i;
            tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(k)];
            tempView.number = [NSString stringWithFormat:@"%@",@(k)];
        }else{
            int m = 0;
            do{
                m  =  arc4random() % (self.number4x4Array.count - 1);
                tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(m)];
                tempView.number = [NSString stringWithFormat:@"%@",@(m)];;
                //             NSLog(@"k=%@,m=%@,number=%@",@(k),@(m),tempView.numberLabel.text);
            }while( m == k);
        }
    }
}
- (void)start5x5{
    int  k  =  arc4random() % (self.numbers5x5Array.count - 1);
    
    int o =  arc4random() % (self.numbers5x5Array.count - 1);
    
    self.targetLabel.text = [NSString stringWithFormat:@"%@",@(k)];
    [[NSUserDefaults standardUserDefaults] setValue:self.targetLabel.text forKey:@"target"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    for (NSInteger i = 0; i < self.numbers5x5Array.count; i++) {
        
        
        FlipView *tempView = self.numbers5x5Array[i];
        tempView.isUse = YES;
        if (o == i) {
            tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(k)];
            tempView.number = [NSString stringWithFormat:@"%@",@(k)];
            self.targetLabel.tag = i;
        }else{
            int m = 0;
            do{
                m  =  arc4random() % (self.numbers5x5Array.count - 1);
                tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(m)];
                tempView.number = [NSString stringWithFormat:@"%@",@(m)];;
                //             NSLog(@"k=%@,m=%@,number=%@",@(k),@(m),tempView.numberLabel.text);
            }while( m == k);
        }
    }
}
- (void)start6x6{
    int  k  =  arc4random() % (self.numbers6x6Array.count - 1);
    
    int o =  arc4random() % (self.numbers6x6Array.count - 1);
    
    self.targetLabel.text = [NSString stringWithFormat:@"%@",@(k)];
    [[NSUserDefaults standardUserDefaults] setValue:self.targetLabel.text forKey:@"target"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    for (NSInteger i = 0; i < self.numbers6x6Array.count; i++) {
        
        
        FlipView *tempView = self.numbers6x6Array[i];
        tempView.isUse = YES;
        if (o == i) {
            tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(k)];
            tempView.number = [NSString stringWithFormat:@"%@",@(k)];
            self.targetLabel.tag = i;
        }else{
            int m = 0;
            do{
                m  =  arc4random() % (self.numbers6x6Array.count - 1);
                tempView.numberLabel.text = [NSString stringWithFormat:@"%@",@(m)];
                tempView.number = [NSString stringWithFormat:@"%@",@(m)];;
                //             NSLog(@"k=%@,m=%@,number=%@",@(k),@(m),tempView.numberLabel.text);
            }while( m == k);
        }
    }
}


#pragma mark - 重置
- (IBAction)resetGuess:(UIButton *)sender{
    switch (self.type) {
        case GTNNumberType4x3:
            [self setDefalutReSet];
            break;
        case GTNNumberType4x4:
            [self set4x4ReSet];
            break;
        case GTNNumberType5x5:
            [self set5x5ReSet];
            break;
        case GTNNumberType6x6:
            [self set6x6ReSet];
            break;
    }
}
- (void)setDefalutReSet{
    
    
    for (FlipView *temp in self.numbersArray) {
        if (!temp.numberLabel.hidden)   [temp flip];
    }
    _indexID = 1;
    self.stepLabel.text = [NSString stringWithFormat:@"step:%@",@(0)];
}
- (void)set4x4ReSet{
    for (FlipView *temp in self.number4x4Array) {
        if (!temp.numberLabel.hidden)   [temp flip];
    }
    _indexID = 1;
    self.stepLabel.text = [NSString stringWithFormat:@"step:%@",@(0)];
}
- (void)set5x5ReSet{
    for (FlipView *temp in self.numbers5x5Array) {
        if (!temp.numberLabel.hidden)   [temp flip];
    }
    _indexID = 1;
    self.stepLabel.text = [NSString stringWithFormat:@"step:%@",@(0)];
}
- (void)set6x6ReSet{
    for (FlipView *temp in self.numbers6x6Array) {
        if (!temp.numberLabel.hidden)   [temp flip];
    }
    _indexID = 1;
    self.stepLabel.text = [NSString stringWithFormat:@"step:%@",@(0)];
}
- (void)handerNotification{
    
    NSString *targget =  [[NSUserDefaults standardUserDefaults]objectForKey:@"target"];
    for (FlipView *temp in self.numbersArray) {
        if ([temp.number isEqualToString:targget]) {
             NSLog(@"%@",temp.number);
        }else{
            
        }
    }
}

- (void)setIndexID:(NSInteger)indexID{
    _indexID = indexID;
    self.stepLabel.text = [NSString stringWithFormat:@"step:%@",@(indexID)];
}
- (void)didFLipView:(FlipView *)filpView{
    self.indexID = self.indexID +1;

}
- (void)Tips{
    UIAlertController *vc = [UIAlertController alertControllerWithTitle:@"success" message:[NSString stringWithFormat:@"You finished it in %@ steps",_stepLabel.text] preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok  = [UIAlertAction actionWithTitle:@"Go on next" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [vc addAction:ok];
    [self presentViewController:vc animated:YES completion:^{
        
    }];
}

#pragma mark - 生产图片
- (UIImage *)makeImageWithView:(UIView *)view{
    
    CGSize s = view.bounds.size;
    
    UIGraphicsBeginImageContextWithOptions(s, NO, [UIScreen mainScreen].scale);
    
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage*image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return image;
}
#pragma mark - 图片存储在沙盒中
- (NSString *)saveImageToCacheUseImage:(UIImage *)image
{
    //获取当前时间戳拼接到文件尾部,防止存储图片多时地址重复
    NSDate *currentDate = [NSDate dateWithTimeIntervalSinceNow:0];
    // *1000 是精确到毫秒，不乘就是精确到秒
    NSTimeInterval currentTime=[currentDate timeIntervalSince1970]*1000;
    NSString *timeString = [NSString stringWithFormat:@"%.0f", currentTime];
    
    //这个路径是存储到本地用的图片后缀地址
    NSString *savePath= [NSString stringWithFormat:@"Documents/image_%@.png", timeString];
    //这个路径是将图片存入沙盒时的路径
    NSString *imageAllPath = [NSHomeDirectory() stringByAppendingPathComponent:savePath];
    //存储图片到沙盒,并返回结果
    BOOL result =[UIImagePNGRepresentation(image) writeToFile:imageAllPath atomically:YES];
    
    if (result == YES) {
        NSLog(@"保存成功");
    } else {
        NSLog(@"保存失败");
    }
    return savePath;
}
-(void)saveR:(NSString *)guessNumberType{
    if (guessNumberType == nil) {
        guessNumberType = @"GuessNumderDefaultType";
    }
    UIImage *image = [self makeImageWithView:self.view];
    NSString * cardUrl =  [self saveImageToCacheUseImage:image];
    NSMutableArray *array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:guessNumberType]];
    
    if (array.count == 0) {
        [[NSUserDefaults standardUserDefaults] setValue:@[cardUrl] forKey:guessNumberType];
    }else{
        [array insertObject:cardUrl atIndex:0];
        [[NSUserDefaults standardUserDefaults] setValue:array forKey:guessNumberType];
        
    }
}

@end
