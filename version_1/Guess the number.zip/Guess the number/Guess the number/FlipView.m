//
//  FlipView.m
//  Guess the number
//
//  Created by KOK on 20/12/2020.
//

#import "FlipView.h"
@interface FlipView()
@property (strong,nonatomic) UIImageView *imageView;


@end
@implementation FlipView
- (instancetype)init{
    self = [super init];
    if (self) {
        self.userInteractionEnabled = YES;
     
        [self setUI];
        
    }
    return self;
}
- (void)setUI{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(transition)];
    [self addGestureRecognizer:tap];
    [self addSubview:self.imageView];
    [self addSubview:self.numberLabel];
}
- (void)transition{
    if (self.isUse) {

    }else{
        return;
    }
    if (self.mkDelegate && [self.mkDelegate respondsToSelector:@selector(didFLipView:)]) {
        [self.mkDelegate didFLipView:self];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hitBtn" object:nil];
    
    __weak typeof(self) weakSelf = self;

    [UIView transitionWithView:weakSelf.imageView duration:1.0f options:UIViewAnimationOptionTransitionFlipFromLeft animations:^{
        [weakSelf flip];
    } completion:^(BOOL finished) {
        
    }];
}
- (void)flip{
    _numberLabel.hidden = !_numberLabel.hidden;
    if (!self.isFlipped) {
        self.imageView.image = self.backImage;
        _isFlipped = YES;
    }else{
        self.imageView.image = self.frontImage ;
        self.isFlipped = NO;
       
    }
}
- (UIImageView *)imageView{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:self.bounds];
        _imageView.image = self.frontImage;
    }
    return _imageView;
}
- (UILabel *)numberLabel{
    if (!_numberLabel) {
        _numberLabel = [[UILabel alloc]initWithFrame:self.bounds];
        _numberLabel.text = self.number;
        _numberLabel.textAlignment = NSTextAlignmentCenter;
        _numberLabel.hidden = YES;
    }
    return _numberLabel;
}
@end
