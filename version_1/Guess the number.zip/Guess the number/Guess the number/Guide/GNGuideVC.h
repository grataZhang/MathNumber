

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GNGuideVCDelegate <NSObject>
- (void)didClickCancel;



@end

@interface GNGuideVC : UIViewController
@property (weak,nonatomic) id<GNGuideVCDelegate> mkDelegate;

@end

NS_ASSUME_NONNULL_END
