//
//  FlipView.h
//  Guess the number
//
//  Created by KOK on 20/12/2020.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class FlipView;
@protocol FlipViewDelegate <NSObject>

- (void)didFLipView:(FlipView *)filpView;
- (void)didFLipViewFlipFinish:(FlipView *)filpView;
@end
@interface FlipView : UIView

@property (assign,nonatomic) BOOL isUse;

@property (nonatomic, assign) BOOL isFlipped;
@property (strong,nonatomic) UIImage *frontImage;
@property (strong,nonatomic) UIImage *backImage;
@property (strong,nonatomic) NSString *number;
@property (strong,nonatomic) UILabel *numberLabel;
@property (weak,nonatomic) id<FlipViewDelegate> mkDelegate;

- (void)setUI;
- (void)flip;
@end

NS_ASSUME_NONNULL_END
