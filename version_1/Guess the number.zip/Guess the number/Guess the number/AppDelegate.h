//
//  AppDelegate.h
//  Guess the number
//
//  Created by KOK on 19/12/2020.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

